import xbmcaddon

MainBase = 'http://igorlista.at.ua/NewAdd/MenuPrincipal.txt'
addon = xbmcaddon.Addon('plugin.video.igorlistatestes')